package inher;

public enum Gender {
	MALE, FEMALE
}
