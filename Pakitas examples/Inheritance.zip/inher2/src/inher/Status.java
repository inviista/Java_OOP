package inher;

public enum Status {
	OK, NOT_OK
}
