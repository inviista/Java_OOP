package interfaces2;

public interface Game {
	void a();
	void b();
	void c();
	//alternative to d() in CoolGame
//	default void d() {
//		some code
//	}
}
