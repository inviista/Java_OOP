package interfaces2;

public interface CoolGame extends Game{
	void d();
}
